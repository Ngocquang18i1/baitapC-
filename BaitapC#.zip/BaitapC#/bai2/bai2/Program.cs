﻿using System;

namespace Bai2
{
    class Program
    {
        static void Main(string[] args)
        {
            HK x = new HK();
            x.Nhap();
            x.In();
            Console.ReadLine();
        }
    }
}
